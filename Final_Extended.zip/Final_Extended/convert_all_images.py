
# -*- coding: utf-8 -*-

import Image, ImageTk
import os, sys
import struct
from ctypes import *
import Tkinter
import tkFileDialog
import PIL
import Image
import tkMessageBox

libc = cdll.msvcrt

r,b,g = 0,0,0
ls = [r,g,b]
temp = 0

libcall_c = CDLL('processing_extended.so')

root = Tkinter.Tk(className = "\RGB(888)->RGB(565) Converter_Extended")
menubar = Tkinter.Menu(root)
frame = Tkinter.Frame(root)


def exit_mainloop ():
    global root
    root.destroy() # this will cause mainloop to unblock.

def help_about():
    tkMessageBox.showinfo("Help...", "This Software is created by Ajay Zapadiya.\n" +
                          "\nThis Program is used to convert RGB(888) format to RGB(565) format. \nIt can be used for any image with any resolution. \n" +
                          "Simply Open the Image and All the Image in that directory will be converted into RGB(565) in the 'output folder' of the directory.\nHere Default Extension is nothing, hence FILE type." +
                          "\nI Hope that it will be helpful.\n\n") 

def open_file():
    #frame = Tkinter.Frame(root)
    global frame
    frame.pack()
    frame.fileName = tkFileDialog.askopenfilename()
    im = Image.open(frame.fileName)
    
    label_image = ImageTk.PhotoImage(image = im)
    label = Tkinter.Label(frame, image = label_image)
    label.label_image = label_image  # keep copy
    label.pack(side = "bottom", fill = "both", expand = "yes")
    
    
    "This is used to find the name of file without path : "
    rev_name = frame.fileName[-1:-len(frame.fileName)-1:-1]
    actual_name = rev_name[rev_name.find("/")-1:rev_name.find("."):-1]
    ext = frame.fileName[frame.fileName.find(".")+1:] # will return only jpeg or jpg not ".jpeg" or ".jpg"
    path = frame.fileName[:frame.fileName.find(actual_name)]

    print "-"*70
    print "Source Path = " + path
    print "-"*70
    
    for i in os.listdir(path):
        if i[i.find(".")+1:] == ("jpeg") or i[i.find(".")+1:] == ("jpg") or i[i.find(".")+1:] == ("png") or i[i.find(".")+1:] == ("bmp"):
            im_data_aquire(path + i)
            print "*"*50

    print "-"*70
    print "Destination Path = " + path +"ouptput_folder"
    print "-"*70
    
    root.mainloop()


def im_data_aquire(Im_name):
    im = Image.open(Im_name)
    pix = im.load()

    rev_name = Im_name[-1:-len(Im_name)-1:-1]
    actual_name = rev_name[rev_name.find("/")-1:rev_name.find("."):-1]
    ext = frame.fileName[Im_name.find("."):]
    f_name = actual_name + ".txt"

    src_path = Im_name[:Im_name.find(actual_name)]
    dst_path = src_path + "/output_folder/"
    src_path_txt = src_path + f_name
    dst_path_file = dst_path + actual_name

    if not os.path.exists(dst_path):
        os.makedirs(dst_path)
        
    
    print "File_Name = " + actual_name + ext
    print ('Image Size = %d x %d' % (im.size[0],im.size[1]))
    print "Image Format : " + im.format
    
    f = open(src_path_txt,'w+')
    for i in range(im.size[0]):
        for j in range(im.size[1]):
            ls = list(im.getpixel((i,j)))
            for k in range(len(ls)):
                temp = ls[k]
                temp = str(temp) + " "
                f.write(temp)
    f.close()
    filename = c_char_p(src_path_txt)
    new_filename = c_char_p(dst_path_file)
    im_width, im_height = c_uint(im.size[0]), c_uint(im.size[1])
    libcall_c.data_processing(filename, im_width, im_height,  new_filename)
    os.remove(src_path_txt) # This will remove your txt file and save space...
    
    print "The size of Raw Image File : %d Bytes" % (im.size[0]*im.size[1]*2)
    #print "*"*70



filemenu = Tkinter.Menu(menubar, tearoff = 0)
menubar.add_cascade(label = "File", menu = filemenu)
filemenu.add_command(label = "Open", command = open_file)
filemenu.add_separator()
filemenu.add_command(label = "Exit", command = exit_mainloop)

helpmenu = Tkinter.Menu(menubar, tearoff = 0)
menubar.add_cascade(label= "Help", menu = helpmenu)
helpmenu.add_command(label="About...", command=help_about)

root.config(menu = menubar)
root.mainloop()
